export interface DriverLocation {
  lat: number;
  lng: number;
}

export interface DriverStatus {
  isAvailable: boolean;
  currentLocation?: DriverLocation;
  lastUpdate?: string;
}

export interface Driver {
  id: string;
  name: string;
  status: DriverStatus;
  vehicleType: 'motor' | 'cycle';
  plateNumber?: string;
  rating: number;
  totalDeliveries: number;
}
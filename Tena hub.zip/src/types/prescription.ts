export interface Prescription {
  id: string;
  patientName: string;
  doctorName: string;
  issueDate: string;
  expiryDate: string;
  status: 'pending' | 'verified' | 'rejected';
  imageUrl: string;
  notes?: string;
  verifiedAt?: string;
  verifiedBy?: string;
}

export interface UploadedPrescription {
  id: string;
  imageUrl: string;
  uploadedAt: string;
}
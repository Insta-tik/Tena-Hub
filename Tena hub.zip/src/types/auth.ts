export type UserRole = 'customer' | 'pharmacy' | 'driver' | 'admin';

export interface User {
  id: string;
  email: string;
  role: UserRole;
  name: string;
  password?: string; // Optional because we don't want to expose it in all contexts
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}
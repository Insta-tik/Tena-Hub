import { useState, useEffect } from 'react';

interface DriverStatus {
  isAvailable: boolean;
  lastUpdate?: Date;
}

export const useDriverStatus = () => {
  const [status, setStatus] = useState<DriverStatus>(() => {
    const savedStatus = localStorage.getItem('driverStatus');
    return savedStatus 
      ? JSON.parse(savedStatus) 
      : { isAvailable: false, lastUpdate: new Date() };
  });

  useEffect(() => {
    localStorage.setItem('driverStatus', JSON.stringify(status));
  }, [status]);

  const toggleAvailability = () => {
    setStatus(prev => ({
      isAvailable: !prev.isAvailable,
      lastUpdate: new Date()
    }));
  };

  return {
    isAvailable: status.isAvailable,
    lastUpdate: status.lastUpdate,
    toggleAvailability
  };
};
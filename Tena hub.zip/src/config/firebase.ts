// Firebase configuration placeholder
// This would be replaced with actual Firebase config in a real app
export const firebaseConfig = {
  apiKey: "your-api-key",
  authDomain: "your-auth-domain",
  projectId: "your-project-id",
  storageBucket: "your-storage-bucket",
  messagingSenderId: "your-messaging-sender-id",
  appId: "your-app-id"
};

// Mock auth functions
export const auth = {
  signInWithEmailAndPassword: async (email: string, password: string) => {
    return Promise.resolve({
      user: {
        email,
        uid: 'mock-uid',
      }
    });
  },
  signOut: async () => Promise.resolve(),
  onAuthStateChanged: (callback: (user: any) => void) => {
    // Mock auth state change
    callback(null);
    return () => {}; // Cleanup function
  }
};